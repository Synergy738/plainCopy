ICON FILES NEEDED
=================

This extension requires three icon files:
- icon16.png (16x16 pixels)
- icon48.png (48x48 pixels)  
- icon128.png (128x128 pixels)

You can create these icons using any image editor, or use the generate-icons.html file
in this directory to generate simple placeholder icons.

For production use, create proper icons that represent the PlainCopy extension.
